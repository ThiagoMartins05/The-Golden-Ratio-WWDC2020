
import PlaygroundSupport
import SpriteKit

public func End(){
    
    
    class GameScene: SKScene {
        
        
        override func sceneDidLoad() {
            
            self.anchorPoint = .init(x: 0.5, y: 0.5)
            
            self.scaleMode = .aspectFit
            
            let final = SKSpriteNode(imageNamed: "final")
            final.setScale(1.42)
            final.position.x = 36
            
            self.addChild(final)
            self.backgroundColor = #colorLiteral(red: 0.0, green: 0.0, blue: 0.0, alpha: 1.0)
            
            final.run(.scale(by: 0.13, duration: 3))
            
        }
        
    }
    
    
    var view = SKView(frame: CGRect(origin: .zero, size: CGSize(width: 500, height: 500)))
    
    
    var scene = GameScene(size: view.frame.size)
    
    
    view.presentScene(scene)
    
    
    PlaygroundPage.current.setLiveView(view)
    
}
