import PlaygroundSupport
import SpriteKit
import Foundation

var fundo2 = SKSpriteNode(imageNamed: "fundo2")
var ratioG = SKSpriteNode(imageNamed: "ratio1")
public var counter: Int = 0

var coluna = SKSpriteNode(imageNamed: "coluna")
var telhado = SKSpriteNode(imageNamed: "telhado")
var transp2 = SKSpriteNode(imageNamed: "transp2")
var buttonBA = SKSpriteNode(imageNamed: "netx")
var museu = SKSpriteNode(imageNamed: "museum")
var sheet = SKSpriteNode(imageNamed: "capa")
var ratvit = SKSpriteNode(imageNamed: "ratvit")



var tl : Bool = false
var cl : Bool = false


public func BuildsAndArt(){
    
    
    class GameScene: SKScene {
        
        override func sceneDidLoad() {
            self.anchorPoint = .init(x: 0.5, y: 0.5)
            
            self.scaleMode = .aspectFit
            

            self.addChild(museu)
            self.addChild(sheet)
            
            sheet.name = "sheet"
            sheet.isHidden = true
            museu.isHidden = true
            
            self.addChild(fundo2)
            fundo2.setScale(0.54)
            
            self.addChild(buttonBA)
            buttonBA.setScale(0.42)
            buttonBA.position.y = -241
            buttonBA.zPosition = 170
            buttonBA.name = "next"
            buttonBA.isHidden = true
            
            
            
            ratioG.setScale(0.1)
            ratioG.position.y = -95
            ratioG.position.x = 39
            
            
            coluna.position = CGPoint(x: -106.57, y: -216)
            coluna.setScale(0.2302)
            self.addChild(coluna)
            coluna.name = "coluna"
                
            telhado.position = CGPoint(x:-63.95 , y: -61.38)
            telhado.setScale(0.54)
            self.addChild(telhado)
            telhado.name = "telhado"
            
            transp2.setScale(0.426)
            transp2.zPosition = 20
            transp2.position.y = 85.26
            self.addChild(transp2)
            
            
            //self.addChild(museu)
            museu.setScale(0.54)
            
            self.addChild(ratvit)
            ratvit.setScale(0.048)
            ratvit.position.y = -97
            ratvit.isHidden = true
            
            self.isUserInteractionEnabled = false
            
            counter  = 1
            
            TextIntroBA()
            
        }
        
        override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
            
            for touch in touches{
                let t = touches.randomElement()!
                let location = touch.location(in: self)
                let node: SKNode = self.atPoint(location)
                
                //drag the column and the roof
                if(counter == 1){
                    
                    if(node.name == "coluna"){
                        if let location = touches.first?.location(in: self) {
                            coluna.position.x = location.x
                            coluna.position.y = location.y
                        
                        }
                    }
                    
                    if(node.name == "telhado"){
                        if let location = touches.first?.location(in: self) {
                            telhado.position.x = location.x
                            telhado.position.y = location.y
                            
                        }
                    }
                    
                }
                
                //move the sheet
                if(counter == 5){
                    if(node.name == "sheet"){
                         
                         if let location = touches.first?.location(in: self) {
                         sheet.position.x = location.x
                         sheet.position.y = location.y
                         }
 
                    }
                }
                
            }
        }
        
        override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
            // compare if the column andd the roof are in the right place
            if(counter == 1){
                columnPosition()
                roofPosition()
                
                if(tl == true && cl == true){
                    self.isUserInteractionEnabled = false
                    counter = 2
                    ratioParthenon()
                    
                }
            }
            
            if(counter == 3){
            for touch in touches{
                let t = touches.randomElement()!
                let location = touch.location(in: self)
                let node: SKNode = self.atPoint(location)
                
                if(node.name == "next"){
                    
                    print("")
                    counter = 4
                    ratioG.isHidden = true
                    transp2.isHidden = true
                    art()
                    
                }
                
            }
        }
            
            if(counter == 5){
                if((sheet.position.x <= 28 || sheet.position.x >= 7) && (sheet.position.y <= -85 || sheet.position.y >= -43 )){
                    
                    TextPaint()
                    
                    print("aqui")
                    
                }
                
            }
            
            if(counter == 7){
                for touch in touches{
                    let t = touches.randomElement()!
                    let location = touch.location(in: self)
                    let node: SKNode = self.atPoint(location)
                    
                    if(node.name == "next"){
                        
                        print("")
                        
                        PlaygroundPage.current.navigateTo(page: .next)
                        
                    }
                    
                }
                
            }
            

            }
        
        
        
        
        
        
        func TextIntroBA(){
            
            if(counter == 1){
                print("eretert")
                let spriteSheet1: [SKTexture] = [
                    // SKTexture(imageNamed: "texto8"),
                    SKTexture(imageNamed: "texto9"),
                    SKTexture(imageNamed: "texto10"),
                    SKTexture(imageNamed: "texto11"),
                    SKTexture(imageNamed: "texto12"),
                    SKTexture(imageNamed: "texto13")
                ]
                
                
                transp2.run(.animate(with: spriteSheet1, timePerFrame:7))
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 28){
                    self.isUserInteractionEnabled = true
                    
                }
                
                
            }
            
        }
        
        func columnPosition(){
            if(coluna.position.x <= -2 && coluna.position.x >= -24 && coluna.position.y <= -115 && coluna.position.y >= -140){
                coluna.position = CGPoint(x: -13.5, y: -127.9)
                coluna.isUserInteractionEnabled = false
                cl = true
            }
        }
        
        func roofPosition(){
            if(telhado.position.x <= 23.47 && telhado.position.x >= -4.5 && telhado.position.y <= -16.31 && telhado.position.y >= -40.53){
                telhado.position = CGPoint(x:9.95 , y: -28.7)
                telhado.isUserInteractionEnabled = false
                tl = true
                
            }
        }
        
        //apply the golden ratio in the parthenon
        
        func ratioParthenon(){
            if(counter == 2){
                self.addChild(ratioG)
                //ratioG.isHidden = false
                ratio.zPosition = 10
                ratioG.run(.scale(to: 0.54, duration: 2))
                
                buttonBA.isHidden = false
                
                counter = 3
                self.isUserInteractionEnabled = true
                buttonBA.zPosition = 20
                buttonBA.name = "next"
                
                
            }
            
        }
        
        func art(){
            transp2.isHidden = true
            self.isUserInteractionEnabled = false
            self.removeChildren(in: [botao])
            
            
            self.removeChildren(in: [coluna])
            self.removeChildren(in: [telhado])
            self.removeChildren(in:[fundo2])
            
            
            sheet.isHidden = false
            museu.isHidden = false
            sheet.position.y = -127.9
            sheet.position.x = -11.3
            
            sheet.run(.scale(to: 0.54, duration: 2))
            museu.run(.scale(to: 0.54, duration: 2))
            
            Paint()
            
        }
        
        func Paint(){
            buttonBA.isHidden = true
            transp2.zPosition = 1222
            let spriteSheet3: [SKTexture] = [
                SKTexture(imageNamed: "texto14"),
                SKTexture(imageNamed: "texto15"),
                SKTexture(imageNamed: "texto16"),
            ]
            
            transp2.zPosition = 110
            
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3){
                transp2.isHidden = false
                transp2.run(.animate(with: spriteSheet3, timePerFrame:5))
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 12){
                    self.isUserInteractionEnabled = true
                    counter = 5
                    
                }
                
            }
            
            
            
            
        }
    
        func TextPaint(){
            
            sheet.isHidden = true
            
            let spriteSheet4: [SKTexture] = [
                SKTexture(imageNamed: "texto17"),
                SKTexture(imageNamed: "texto18"),
                SKTexture(imageNamed: "texto19"),
                SKTexture(imageNamed: "texto20"),
            ]
            
            transp2.run(.animate(with: spriteSheet4, timePerFrame:4))
            
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 8){
                ratvit.zPosition = 1000
                ratvit.isHidden = false
                }
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 13){
                buttonBA.isHidden = false
                counter = 7
            }
            
            
        }
    
        
    }
    
    var view = SKView(frame: CGRect(origin: .zero, size: CGSize(width: 518, height: 700)))
    var scene = GameScene(size: view.frame.size)
    view.presentScene(scene)
    PlaygroundPage.current.setLiveView(view)
    
}
