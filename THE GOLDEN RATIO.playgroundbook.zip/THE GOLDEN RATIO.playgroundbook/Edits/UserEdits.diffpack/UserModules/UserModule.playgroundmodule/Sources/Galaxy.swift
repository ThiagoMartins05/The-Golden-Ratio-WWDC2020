import PlaygroundSupport
import SpriteKit
import Foundation


//func didChangeSize(_ oldSize: CGSize)
var i:Int = 0
let fundo1 = SKSpriteNode(imageNamed: "Frame 1")
public var botao = SKSpriteNode(imageNamed: "start")
let transp = SKSpriteNode(imageNamed: "transp")
let telescopio = SKSpriteNode(imageNamed: "telescopio")
let galaxia = SKSpriteNode(imageNamed: "galaxia")
let ratio = SKSpriteNode(imageNamed: "golden ratio")
let capa = SKSpriteNode(imageNamed: "Frente 1")
let frib = SKSpriteNode(imageNamed: "frib")
let geometric = SKSpriteNode(imageNamed: "geometric")
let ratios = SKSpriteNode(imageNamed: "ratios")
let texto1 = SKSpriteNode(imageNamed:"texto1")

public func Galaxy(){
    
    class GameScene: SKScene {
        
        override func sceneDidLoad() {
            self.anchorPoint = .init(x: 0.5, y: 0.5)
            self.scaleMode = .aspectFit
                //fundo2.setScale(0.38)
            fundo1.setScale(0.54)
            
            self.addChild(fundo1)
            
            capa.setScale(0.63)
            self.addChild(capa)
            
            botao.setScale(0.17)
            botao.position.y = -241
            self.addChild(botao)
            botao.name = "botao"
            
            self.addChild(transp)
            transp.position.y = 0
            transp.setScale(0.54)
            
            
            self.addChild(geometric)
            geometric.setScale(0.483)
            geometric.isHidden = true
            
            self.addChild(ratios)
            ratios.setScale(0.483)
            ratios.isHidden = true
            
            self.addChild(frib)
            frib.setScale(0.54)
            frib.isHidden = true
            
            i = 1
            
        }
        
        override func didChangeSize(_ oldSize: CGSize) {
            self.scaleMode = .aspectFit
        }
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            
            for touch in touches{
                let t = touches.randomElement()!
                let location = touch.location(in: self)
                let node: SKNode = self.atPoint(location)
                
                if(i==1){
                    if node.name == "botao"{
                        startWasPressed()
                        i = 2
                    }
                    
                }
                
                if(i==2){
                    if node.name == "botao"{
                        
                        i = 3
                    }
                }
                
                
                if(i==4){
                    if node.name == "botao"{
                        self.removeChildren(in: [geometric])
                        self.removeChildren(in: [ratios])
                        botao.isHidden = true
                        telescope()
                    }
                }
                
                if (i == 6){
                    if node.name == "botao"{
                        
                        PlaygroundPage.current.navigateTo(page: .next)
                        
                    }
                    
                }
                
                
            }
            
        }
        
        override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
            
            if let location = touches.first?.location(in: self) {
                // telescopio.run(.move(to: location, duration: 0.5))
                if(i == 5){
                    telescopio.position.x = location.x
                    telescopio.position.y = location.y
                }
                
                
            }
            
        }
        override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
            
            if(i == 5){
                if (telescopio.position.x < -100 && telescopio.position.x > -225 && telescopio.position.y < 400 && telescopio.position.y > 226) {
                    print("")
                    
                    i = 6
                    
                    galaxyZoom()
                }
            }
            
            
            
            
        }
        
        
        func startWasPressed(){
            
            self.removeChildren(in: [capa])
            self.removeChildren(in: [botao])
            
            let spriteSheetd: [SKTexture] = [
                SKTexture(imageNamed: "Intro1"),
                SKTexture(imageNamed: "Intro2"),
            ]
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 0.5){
                transp.run(.animate(with: spriteSheetd, timePerFrame:7))
                
            }
                
            
            let spriteSheetds: [SKTexture] = [
                SKTexture(imageNamed: "Intro3"),
                SKTexture(imageNamed: "Intro4"),
            ]
            
                DispatchQueue.main.asyncAfter(deadline: .now() + 14.9){
                    transp.position.y = 241
                    frib.isHidden = false
                    transp.run(.animate(with: spriteSheetds, timePerFrame:7))
                    
                        // show the geometric forms
                    DispatchQueue.main.asyncAfter(deadline: .now() + Double(7)){
                        self.removeChildren(in: [frib])
                        geometric.isHidden = false
                    } 
                            // show the curve
                        DispatchQueue.main.asyncAfter(deadline: .now() + 9){
                            ratios.isHidden = false
                            
                            botao = SKSpriteNode(imageNamed: "netx")
                            botao.setScale(0.43)
                            botao.position.y = -241.58
                            self.addChild(botao)
                            botao.name = "botao"
                            i = 4
                            
                        }
                        
                        
                    
                    
                    
                }
                
                
                
                
            
            
        }
        
        func telescope(){
            
            i = 5
            
            transp.isHidden = true
            galaxia.setScale(0.142)
            galaxia.position.x = -170.5
            galaxia.position.y = 284
            
            self.addChild(galaxia)
            self.addChild(telescopio)
            
            self.addChild(texto1)
            texto1.setScale(0.57)
            
        }
        
        func galaxyZoom(){

            self.removeChildren(in: [texto1])
            
            telescopio.run(.scale(by: 20, duration: 5))
            galaxia.run(.group([
                .move(to: .init(x: 0, y: -71), duration: 3),
                .scale(by: 4.26, duration: 3),
            ]))
            self.isUserInteractionEnabled = false
            self.removeChildren(in: [telescopio])
            galaxyFinalText()
            
        }
        
        func galaxyFinalText(){
            
            
            let spriteSheet: [SKTexture] = [
                SKTexture(imageNamed: "texto2"),
                SKTexture(imageNamed: "texto3"),
                SKTexture(imageNamed: "texto4"),
                SKTexture(imageNamed: "texto5"),
                SKTexture(imageNamed: "texto6"),
            ]
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 3){
                transp.isHidden = false
                transp.position.y = 213.2
                transp.run(.animate(with: spriteSheet, timePerFrame:3))
            }
            
            addRatioAndNext()
        }
        
        func addRatioAndNext(){
            DispatchQueue.main.asyncAfter(deadline: .now() + 18){
                self.addChild(ratio)
                ratio.run(.scale(to: 0.55, duration: 2))
                
                ratio.position.x = -14.2
                ratio.position.y = -71.05
                
                botao.isHidden = false
                botao.name = "botao"
                botao.zPosition = 5
                botao.position.y = -253
                galaxia.isUserInteractionEnabled = false
                self.isUserInteractionEnabled = true}
            
            
        }
        
    }
    var view = SKView(frame: CGRect(origin: .zero, size: CGSize(width: 518, height: 700)))
    var scene = GameScene(size: view.frame.size)
    view.presentScene(scene)
    PlaygroundPage.current.setLiveView(view)
    
}
