
import PlaygroundSupport
import SpriteKit
import Foundation

let sunflower1 = SKSpriteNode(imageNamed: "cabeca")
let b1 = SKSpriteNode(imageNamed: "butterfly")
let b2 = SKSpriteNode(imageNamed: "b2")
let jardim = SKSpriteNode(imageNamed: "jardin")
let tr2 = SKSpriteNode(imageNamed: "transp")
let cabeca = SKSpriteNode(imageNamed: "cabeca2")
let rat = SKSpriteNode(imageNamed: "golden ratio")
let touch = SKSpriteNode(imageNamed: "touch")
let end = SKSpriteNode(imageNamed: "finishbut")

var control: Int = 0
public func Nature(){
    class GameScene: SKScene {
        
        
        override func sceneDidLoad() {
            
            self.anchorPoint = .init(x: 0.5, y: 0.5)
            self.scaleMode = .aspectFit
            
            self.addChild(jardim)
            jardim.setScale(0.54)
            
            tr2.setScale(0.54)
            tr2.position.y = 85.26
            self.addChild(tr2)
            
            touch.setScale(0.108)
            touch.position.y = -287
            touch.position.x = 194
            touch.isHidden = true
            self.addChild(touch)
            touch.name = "touch"
            
            
            self.addChild(cabeca)
            cabeca.isHidden = true
            
            self.addChild(sunflower1)
            sunflower1.setScale(0.142)
            sunflower1.position.y = -208.9
            sunflower1.position.x = 38.4
            
            self.addChild(b1)
            b1.setScale(0.142)
            b1.position.y = -184.75
            b1.position.x = 35.52
            b1.name = "b1"
            
            self.addChild(b2)
            b2.setScale(0.17)
            b2.position.y = -217
            b2.position.x = 56.84
            b2.name = "b2"
            
            rat.setScale(1.42)
            rat.position.y = 0
            rat.position.x = -14.2
            self.addChild(rat)
            rat.isHidden = true
            
            
            
            control = 1
            textojardin1()
            
            self.isUserInteractionEnabled = false
            
        }
        override func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
            for touch in touches{
                let t = touches.randomElement()!
                let location = touch.location(in: self)
                let node: SKNode = self.atPoint(location)
                
                
                if(control == 6){
                    if node.name == "touch" {
                        finishp()
                        
                    }
                    
                }
                
                if(control == 10)
                {
                    if(node.name == "end"){
                        print("")
                        PlaygroundPage.current.navigateTo(page: .next)
                        
                    }
                    
                }
            }
            
        }
        
        override func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
            if let location = touches.first?.location(in: self) {
                let node: SKNode = self.atPoint(location)
                
                
                if control == 2{
                    if((b1.intersects(sunflower1) == false)&&(b2.intersects(sunflower1) == false)){
                        print("")
                        control = 3
                        tr2.isHidden = true
                        zoomflor()
                        self.isUserInteractionEnabled = false
                    }
                    
                }
                
                
                    if(node.name == "touch"){
                        finishp()
                    }
                    
                
                
            }
        }
        
        override func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
            
            if let location = touches.first?.location(in: self) {
                let node: SKNode = self.atPoint(location)
                
                if(control == 2){
                    if node.name == "b2"{
                        b2.position.x = location.x
                        b2.position.y = location.y
                    }
                    
                    if node.name == "b1"{
                        b1.position.x = location.x
                        b1.position.y = location.y
                    }
                    

                    
                    
                }
                
                
                
            }
            
        }
        
        func textojardin1(){
            if(control == 1){
                let spriteSheetd: [SKTexture] = [
                    SKTexture(imageNamed: "texto21"),
                    SKTexture(imageNamed: "texto22"),
                    SKTexture(imageNamed: "texto23"),
                    SKTexture(imageNamed: "texto24"),
                    SKTexture(imageNamed: "texto25"),
                ]
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 2){
                    tr2.run(.animate(with: spriteSheetd, timePerFrame:6))
                    control = 2
                }
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 29){
                    self.isUserInteractionEnabled = true
                }
            }
        }
        
        func zoomflor(){
            if control == 3{
                self.removeChildren(in: [sunflower1])
                cabeca.isHidden = false
                cabeca.setScale(0.2)
                
                cabeca.run(.scale(by: 5.684, duration: 2))
                b1.run(.move(to: CGPoint(x: -200.52, y: 20), duration: 2))
                b2.run(.move(to: CGPoint(x: 200.52, y: 170), duration: 2))
                b1.isUserInteractionEnabled = false
                b2.isUserInteractionEnabled = false
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 2){
                    rat.isHidden = false
                    rat.run(.scale(by: 0.185, duration: 2))
                    DispatchQueue.main.asyncAfter(deadline: .now() + 3.5){
                        self.removeChildren(in: [rat])
                        self.removeChildren(in: [cabeca])
                        control = 4
                        self.challenge()
                    }
                }
                
            }
            
            
            
        }
        
        func challenge(){
            if control == 4{
                
                let spriteSheetds: [SKTexture] = [
                    SKTexture(imageNamed: "texto29"),
                    SKTexture(imageNamed: "texto30"),
                ]
                tr2.isHidden = false
                tr2.run(.animate(with: spriteSheetds, timePerFrame:4))
                control = 2
                DispatchQueue.main.asyncAfter(deadline: .now() + 3){
                    touch.isHidden = false
                    
                }
                
                control = 5
            }
            self.isUserInteractionEnabled = true
            
            }
        
        func finishp() {
            self.isUserInteractionEnabled = false
            let goodjob: [SKTexture] = [
                SKTexture(imageNamed: "texto2"),
            ]
            tr2.isHidden = false
            tr2.run(.animate(with: goodjob, timePerFrame: 2 ))
            DispatchQueue.main.asyncAfter(deadline: .now() + 2){
                
                self.addChild(end)
                end.setScale(1)
                end.name = "end"
                
                end.run(.scale(by: 0.5, duration: 2))
                end.run(.move(to: CGPoint(x:160 ,y:-290), duration: 2.3))
                control = 10
                self.isUserInteractionEnabled = true
            }
            
            
            
        }
        
    }
    
    
    var view = SKView(frame: CGRect(origin: .zero, size: CGSize(width: 518, height: 700)))
    
    
    var scene = GameScene(size: view.frame.size)
    
    
    view.presentScene(scene)
    
    
    PlaygroundPage.current.setLiveView(view)
    
}


